#include <unistd.h>
#include <stdio.h>
int main()
{
	FILE* numbersFile;
	int* numbersArray = (int*) malloc (100);
	int n=0;
	numbersFile = fopen("numbers.txt","r");
	char number[255];
	while( fscanf(numbersFile,"%s",number)!=EOF)
	{
		numbersArray[n]=atoi(number);
       	 	n+=1;		
	}
	int id=fork();
	if (id==0)
	{
		int i;
		int count=0;
		for (i=0;i<n;i++)
		{
			if (numbersArray[i]%3==0)
			{
				count+=1;
			}
		}
		printf("%d\n",count);

	
	}
	else if(id>0)
	{
		int i;
		int count=0;
		for (i=0;i<n;i++)
		{
			if (numbersArray[i]%2==0)
			{
				count+=1;
			}
		}
		printf("%d\n",count);
	}

	
	
	free(numbersArray);	
	fclose(numbersFile);
	return 0;	

}
