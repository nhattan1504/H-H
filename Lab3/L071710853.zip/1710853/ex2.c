#include <stdio.h>
#include <unistd.h>
int main ()
{
	pid_t id1;
	id1=fork();
	if (id1==0)
	{
		printf("ID of B = %d\n",getpid());
		pid_t id2=fork();
		if (id2==0)
		{
			printf("ID of E = %d\n",getpid());
			pid_t id3=fork();
			if (id3==0)
			{
				printf("ID of I = %d\n",getpid());
			}
		}
		else if (id2>0)
		{
			
			pid_t id4= fork();
			if (id4==0)
			printf("ID of F = %d\n",getpid());
		}
	}
	else if (id1>0)
	{
		printf("ID of A = %d\n",getpid());
		pid_t id5=fork();

		if (id5==0)
		{
			printf("ID of C = %d\n",getpid());
			pid_t id6=fork();
			if (id6==0)
			{
				printf("ID of G = %d\n",getpid());
			}
		}
		else
		{
			pid_t id6=fork();
			if (id6==0)
			{
				printf("ID of D = %d\n",getpid());
			}
		}
	}	
	return 0;
}
