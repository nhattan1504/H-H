#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>

int main(){

pid_t pid1, pid2, pid3, pid4, pid5, pid6, pid7, pid8;
printf("Parent of all A: %d\n",getpid());

pid1 = fork();

if(pid1 == 0){   // A child Process. Lets say B.
    printf("Child with id B: %d and its Parent id: %d \n", getpid(),getppid());
    pid2 = fork();
    if(pid2 == 0){ // A child process. Lets say E.
        printf("Child with id E: %d and its Parent id: %d \n", getpid(),getppid());
		pid3 = fork();
   		if(pid3 == 0){ // A child process. Lets say I.
        	printf("Child with id I: %d and its Parent id: %d \n", getpid(),getppid());
    	}
    }
    pid4 = fork();
    if(pid4 == 0 && pid2 > 0){ // A child process. Lets say F.
        printf("Child with id F: %d and its Parent id: %d \n", getpid(),getppid());
    }
}
if(pid1 > 0){
    pid5 = fork();
    if(pid5 == 0){ // A child process. Lets say C.
        printf("Child with id C: %d and its Parent id: %d \n", getpid(),getppid());
        pid6 = fork();
        if(pid6 == 0){ // A child process. Lets say G.
            printf("Child with id G: %d and its Parent id: %d \n", getpid(),getppid());
        }		
    }
    pid7 = fork();
    if(pid7 == 0 && pid5 > 0){ // A child process. Lets say D.
        printf("Child with id D: %d and its Parent id: %d \n", getpid(),getppid());
    }	
}
for(int i=0; i<7; i++) 
  wait(NULL);  
}
