#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#define  MAX 1000

int main()
{
	int divisible2 = 0, devisible3 = 0, len_a = 0, a[MAX], pid = fork(), i = 0;
	FILE*file = fopen("numbers.txt","r");	
	fscanf(file,"%d",&a[i]);

	while(!feof(file))
	{
		i++;
		len_a++;
		fscanf(file,"%d",&a[i]);
	}
	fclose(file);

	if(pid == 0) 	//child
	{
		for(int k = 0; k < len_a; k++)
		{
			if(a[k] % 3 == 0)
			{
				devisible3++;
			}
		}
		 printf("%d\n", devisible3);
	}

	else if (pid > 0) //parent
	{
	       	for(int k = 0; k < len_a; k++)
		{
			if(a[k]%2 == 0)
			{
				divisible2++;
			}
                }		 
		 printf("%d\n", divisible2);
	}
	return 0;
}



