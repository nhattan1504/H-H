#include<stdio.h>
#include<stdlib.h>
#include"ex1.h"
void *aligned_malloc(unsigned int size, unsigned int align) 
{
	char *ptr,*ptr1,*aligned_ptr;
	unsigned int align_ptr1 = (unsigned int)align - 1;
	ptr = (char *)malloc(size + align + sizeof(void *));
	if(ptr == NULL) return(NULL);

	ptr1 = ptr + sizeof(void *);
	aligned_ptr = ptr1 + (align - ((unsigned int)ptr1 & align_ptr1));
	
	ptr1 = aligned_ptr - sizeof(void *);
	*((int *)ptr1)=(int)(ptr);

	return(aligned_ptr);
}


void *aligned_free(void *ptr) 
{
	int *ptr1=(int *)ptr - 1;
	ptr = (*ptr1);
	free(ptr);
}
