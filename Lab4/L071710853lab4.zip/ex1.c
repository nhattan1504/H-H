#include <stdio.h>
#include <stdlib.h>
#include "ex1.h"
void* aligned_malloc(unsigned int size, unsigned int align)
{
	if (align<=0)
	{
		return NULL;
	}
	void* ptr;
	void* p=malloc(size+align-1 + sizeof(void*));
	if(p!=NULL)
	{
		ptr = (void*) (((size_t)p + sizeof(void*) +align-1) & ~(align-1));
		*((void**)((size_t)ptr - sizeof(void*))) =p;
        	return ptr;
	}
	return NULL;	

}
void* aligned_free(void* ptr)
{
	void *p=*((void**)((size_t)ptr - sizeof(void*)));
	free(p);
	return NULL;
}
