#include <stdio.h>
#include "sum.h"
#include "sub.h"

int main()
{
	int a = 0, b = 0;
	printf("Input a = ");
	scanf("%d",&a);
	printf("Input b = ");
	scanf("%d",&b);
	
	printf("a + b = %d\n",a+b);
	printf("a - b = %d\n",a-b);

	return 0;
}
