#!/bin/bash
name=${1?Error: No name given}
echo "$name" > ex1.txt
uname -a >> ex1.txt
