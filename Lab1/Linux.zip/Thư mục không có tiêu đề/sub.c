#include "sub.h"

int sub(int a, int b)
{
	return a-2*b;
}
