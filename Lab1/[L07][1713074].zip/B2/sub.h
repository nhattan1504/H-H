
//file:sub.h
int sub_number(int a,int b);

