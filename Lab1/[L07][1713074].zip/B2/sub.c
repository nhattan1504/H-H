#include<stdio.h>;
#include "sub.h";
int sub_number(int a,int b)
{
	return a-b;
}


