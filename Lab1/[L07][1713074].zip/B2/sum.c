
#include<stdio.h>;
#include "sum.h";
int sum_number(int a,int b)
{
	return a+b;
}



