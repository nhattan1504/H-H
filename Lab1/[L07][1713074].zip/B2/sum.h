//File:sum.h
int sum_number(int a,int b);


